/*
 * Copyright (C) 2011 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/* Copyright (C) 2012-2014 Freescale Semiconductor, Inc. */

#ifndef ANDROID_INCLUDE_IMX_CONFIG_TWL320AIC3104_H
#define ANDROID_INCLUDE_IMX_CONFIG_TWL320AIC3104_H

#include "audio_hardware.h"



/* These are values that never change */
static struct route_setting defaults_twl320aic3104[] = {
    /* general */
    {
        .ctl_name = NULL,
    },
};

static struct route_setting bt_output_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};

static struct route_setting speaker_output_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};

static struct route_setting hs_output_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};

static struct route_setting earpiece_output_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};

static struct route_setting vx_hs_mic_input_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};


static struct route_setting mm_main_mic_input_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};


static struct route_setting vx_main_mic_input_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};

/*hs_mic exchanged with main mic for sabresd, because the the main is no implemented*/
static struct route_setting mm_hs_mic_input_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};

static struct route_setting vx_bt_mic_input_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};


static struct route_setting mm_bt_mic_input_twl320aic3104[] = {
    {
        .ctl_name = NULL,
    },
};

/* ALSA cards for IMX, these must be defined according different board / kernel config*/
static struct audio_card  twl320aic3104_card = {
    .name = "tlv320aic-audio",
    .driver_name = "tlv320aic-audio",
    .bus_name = "bus1_system_sound_out",
	.bus_name_ext = "bus0_media_out",
    .supported_out_devices = (AUDIO_DEVICE_OUT_EARPIECE |
            AUDIO_DEVICE_OUT_SPEAKER |
            AUDIO_DEVICE_OUT_WIRED_HEADSET |
            AUDIO_DEVICE_OUT_WIRED_HEADPHONE |
            AUDIO_DEVICE_OUT_ANLG_DOCK_HEADSET |
            AUDIO_DEVICE_OUT_ALL_SCO |
            AUDIO_DEVICE_OUT_DEFAULT ),
    .supported_in_devices = (
            AUDIO_DEVICE_IN_COMMUNICATION |
            AUDIO_DEVICE_IN_AMBIENT |
            AUDIO_DEVICE_IN_BUILTIN_MIC |
            AUDIO_DEVICE_IN_WIRED_HEADSET |
            AUDIO_DEVICE_IN_BACK_MIC |
            AUDIO_DEVICE_IN_ALL_SCO |
            AUDIO_DEVICE_IN_DEFAULT),
    .defaults            = defaults_twl320aic3104,
    .bt_output           = bt_output_twl320aic3104,
    .speaker_output      = speaker_output_twl320aic3104,
    .hs_output           = hs_output_twl320aic3104,
    .earpiece_output     = earpiece_output_twl320aic3104,
    .vx_hs_mic_input     = vx_hs_mic_input_twl320aic3104,
    .mm_main_mic_input   = mm_main_mic_input_twl320aic3104,
    .vx_main_mic_input   = vx_main_mic_input_twl320aic3104,
    .mm_hs_mic_input     = mm_hs_mic_input_twl320aic3104,
    .vx_bt_mic_input     = vx_bt_mic_input_twl320aic3104,
    .mm_bt_mic_input     = mm_bt_mic_input_twl320aic3104,
    .card                = 0,
    .out_rate            = 0,
    .out_channels        = 0,
    .out_format          = 0,
    .in_rate             = 0,
    .in_channels         = 0,
    .in_format           = 0,
};

#endif  /* ANDROID_INCLUDE_IMX_CONFIG_TWL320AIC3104_H */
