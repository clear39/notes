#define ENABLE_FEATURE_NTP_AUTH 0

#define ENABLE_FEATURE_NTPD_SERVER 1

#define ENABLE_FEATURE_NTPD_CONF 1

#define ALWAYS_INLINE inline

#define NOINLINE

#define FAST_FUNC

#define RETURNS_MALLOC __attribute__ ((malloc))


#define LOG_TAG "NTPServer"
#define LOG_NDEBUG 0

#include <utils/Log.h>




